const mongoose = require('mongoose');
const connectMongoDB = async () => {
  try {
    await mongoose.connect(process.env.MONGO_URI);
    console.log('✅ MongoDB connected');
  } catch (err) {
    console.error('❌ MongoDB connection failed:', err.message);
    console.warn('⚠️ Running without MongoDB - some features may not work');
  }
};
module.exports = { connectMongoDB };
